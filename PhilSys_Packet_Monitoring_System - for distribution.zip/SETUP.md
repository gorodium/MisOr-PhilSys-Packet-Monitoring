# PhilSys Packet Monitoring Board & Matrix Ticket Automation - Setup Guide

This guide explains how to set up the system on a new machine.

## Prerequisites
1. **Node.js**: Ensure Node.js (version 18 or higher) is installed.
2. **Git**: (Optional) For cloning the repository, though you can simply extract the ZIP.

## Installation Steps

1. **Extract the ZIP file** to your preferred location.
2. **Open a terminal/command prompt** in the extracted folder.
3. **Install dependencies** by running:
   ```bash
   npm install
   ```

## Configuration

The system uses environment variables for configuration (API keys, credentials, etc.). 

1. Locate the `.env.example` file in the main folder.
2. Copy it and rename the copy to exactly `.env`.
3. Open `.env` in a text editor (like Notepad or VS Code) and fill in your specific values:
   - `DATABASE_URL`: By default, it is set to `"file:./dev.db"` which will create a local SQLite database file in your folder. If you have a remote PostgreSQL database, enter the URL here.
   - `GOOGLE_API_KEY`: Your Google Sheets API key (if needed).
   - `MATRIX_API_KEY`: Your Matrix API key.
   - `NAS_USERNAME`, `NAS1_PASSWORD`, `NAS2_PASSWORD`: These can be configured in the UI later, or added here if you modify the backend to use them from `.env`.

## Database Setup

Initialize your database schema and seed the initial data by running:
```bash
npx prisma db push
npm run db:seed
```

## Running the System

To start the system, run:
```bash
npm run dev
```

You can now access the monitoring board in your browser at `http://localhost:3000`.

## Account Setup (First Time)
1. Since you ran the seed script, a default Admin account has been created for you.
2. Go to the login page and use the following credentials:
   - **Username**: `admin`
   - **Password**: `admin`
3. You will be immediately prompted to change this password to something secure.
4. Once logged in as the admin, you can navigate to the User Management dashboard to create accounts for other employees.
5. For new employees you create, their default password will be `changeme`. They will also be forced to change it upon their first login.
